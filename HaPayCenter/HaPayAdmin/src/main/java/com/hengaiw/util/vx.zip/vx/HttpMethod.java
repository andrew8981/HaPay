package com.hengaiw.util.vx;

/**
 * 
 */
public class HttpMethod {

	public static final String POST = "POST";
	public static final String GET = "GET";
	
}
