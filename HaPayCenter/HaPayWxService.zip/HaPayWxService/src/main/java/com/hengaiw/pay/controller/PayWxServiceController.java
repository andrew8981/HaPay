package com.hengaiw.pay.controller;

public class PayWxServiceController {

}
