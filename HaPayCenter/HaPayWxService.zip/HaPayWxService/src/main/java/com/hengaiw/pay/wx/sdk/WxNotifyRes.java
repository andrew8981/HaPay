package com.hengaiw.pay.wx.sdk;

public class WxNotifyRes {

	public static String fail(String msg) {
		
		
		return msg;
		
	}
}
